/* products options */
function initProductOptions(){
  if($j('.productitem-color-js').length){
    $j('.productitem-color-js').each(function(){
      $j(this).find('a').each(function(){
        $j(this).unbind();
        $j(this).click(function(e){
          e.preventDefault();
          var $this = $j(this);
          if($this.attr('href').indexOf('http') > -1) return false;

          if($this.parent().hasClass('active')) return false;
          setNewData($this);

          var val = '.' + $this.attr("data-tag") + '-js';
          var $pr_parent = $j('.'+$this.attr('data-pr_id'));
          if($pr_parent.find('.options-swatch--size').length) {
            $pr_parent.find('.options-swatch--size li').each(function(){
              $j(this).hide();
              $j(this).removeClass('active');
            });
          };
          if($pr_parent.find(val).length) {
            $pr_parent.find(val).first().addClass('active');
            $pr_parent.find(val).show();
          }
        })
      })
    })
  }
  if($j('.productitem-size-js').length){
    $j('.productitem-size-js').each(function(){
      $j(this).find('a').each(function(){
        $j(this).unbind();
        $j(this).click(function(e){
          e.preventDefault();
          var $this = $j(this);
          if($this.attr('href').indexOf('http') > -1) return false;
          if($this.parent().hasClass('active')) return false;
          setNewData($this);
        })
      })
    })
  }
}

$j(document).ready(function() {
  initProductOptions();
  $j(window).bind('reinitProductOptions', initProductOptions);
});